const Header = () => {
	const template = `
    <header>
      <h1>My Parcel App</h1>
      <p>This is a boilerplate for a simple vanilla JS workflow using the Parcel bundler.</p>
    </header>
  `;

	return template;
};

export default Header;
